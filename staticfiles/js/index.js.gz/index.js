// // $(document).ready(function(){
// function createToast(message){
//     alert(message)

//     // var toast = document.createElement('div');
//     // toast.classList.add('position-fixed');
//     // toast.classList.add('top-0');
//     // toast.classList.add('end-0')
//     // toast.classList.add('p-3');
//     // toast.style.zIndex = "11";
//     // var toast_html = `
//     // <div id="liveToast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
//     //   <div class="toast-header">
//     //     <strong class="me-auto">SoftConnect</strong>
//     //     <small>Now</small>
//     //     <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
//     //   </div>
//     //   <div class="toast-body">
//     //     ${message}
//     //   </div>
//     // </div>
//     // `
//     // toast.innerHTML = toast_html
//     // document.getElementById("body").appendChild(toast)
// }
// // });
