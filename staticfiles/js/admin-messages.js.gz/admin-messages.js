
$(document).ready(function(){
    function createModalForm(message_obj){
        var form_container = document.createElement("div");
        var message_view = document.createElement("div");
        message_view.classList.add("row", "g-2")
        form_container.classList.add("p-2","border", "border-light", "rounded");
        [
            { key: "Reference Code: ", value: message_obj.fields.message_reference_code },
            { key: "Email: ", value: message_obj.fields.email },
            { key: "Subject: ", value: message_obj.fields.message_subject },
            { key: "Date: ", value: message_obj.fields.date },
            { key: "Phone: ", value: message_obj.fields.phone },
            { key: "Answered: ", value: message_obj.fields.is_responded },
            { key: "Marked urgent: ", value: message_obj.fields.is_urgent},
            { key: "Message: ", value: message_obj.fields.message_body}
        ].forEach(attr =>{
            var message_element_label = document.createElement("div");
            message_element_label.classList.add("col-12","col-md-4", "col-xxl-3", "p-1", "text-break", "fw-bold")
            message_element_label.innerText = attr.key;
            var message_element_value = document.createElement("div");
            message_element_value.classList.add("col-12","col-md-8", "col-xxl-9", "p-1", "border", "border-light", "rounded", "text-break")
            message_element_value.innerText = attr.value;
            message_view.appendChild(message_element_label);
            message_view.appendChild(message_element_value);

        })
        form_container.appendChild(message_view)
        return form_container
    }
    function showModal(message_obj){
        //$('#modal-view-message').modal('show')
        var modal = document.createElement("div");

        modal.classList.add("modal", "fade");
        const createAndSetAttributes = (element, attributes) => {
            attributes.forEach(attr => {
                element.setAttribute(attr.key, attr.value);
            });
        };
        createAndSetAttributes(modal, [
            { key: "id", value: "modal-view-message" },
            { key: "data-bs-backdrop", value: "static" },
            { key: "data-bs-keyboard", value: "true" },
            { key: "tabindex", value: "-1" },
            { key: "aria-labelledby", value: "modal-uploaded-view-message-label" },
            { key: "aria-hidden", value: "true" }
        ]);
    
        var modal_dialog = document.createElement("div");
        modal_dialog.classList.add("modal-dialog", "modal-xl","modal-dialog-centered", "modal-dialog-scrollable")
    
        var modal_content = document.createElement("div")
        modal_content.classList.add("modal-content")
        var modal_header = document.createElement("div")
        modal_header.classList.add("modal-header")
        var modal_title = document.createElement("div");
        modal_title.classList.add("modal-title", "h1", "fs-5");
        modal_title.innerHTML = `From: <span>${message_obj.fields.user_name}</span>` 
        var modal_close_btn = document.createElement("button");
        modal_close_btn.classList.add("btn-close");
        createAndSetAttributes(modal_close_btn, [
            { key: "type", value: "button" },
            { key: "data-bs-dismiss", value: "modal" },
            { key: "aria-label", value: "Close" }
        ]);
        modal_close_btn.addEventListener('click', function(){
            modal.remove()
        })
        var modal_body = document.createElement("div");
        modal_body.classList.add("modal-body")
        modal_body.appendChild(createModalForm(message_obj))
        var modal_footer = document.createElement("div")
        modal_footer.classList.add("modal-footer")
        
        
        modal_header.appendChild(modal_title)
        modal_header.appendChild(modal_close_btn)
        modal_content.appendChild(modal_header)
        modal_content.appendChild(modal_body)
        modal_content.appendChild(modal_footer)
        modal_dialog.appendChild(modal_content)
        modal.appendChild(modal_dialog)
        document.body.appendChild(modal)

        $('#modal-view-message').modal('show')

    }


    $('#form-get-messages').submit(function(event){
        event.preventDefault();

        var formData = new FormData(this);

        var table_container = document.createElement('div');
        table_container.classList.add('table-responsive-md');
        var table = document.createElement('table');
        table.classList.add('table');
        table.classList.add('table-striped');
        table.classList.add('table-hover');
        var table_head = document.createElement('thead');
        var table_row_head = document.createElement('tr');;
        ["#", "Sender","Email", "Message", "Answered"].forEach(function(value){
            var th = document.createElement('th');;
            th.setAttribute('scope','col');
            th.innerHTML = value;
            table_row_head.appendChild(th);
        });

        table_head.append(table_row_head)
        table.appendChild(table_head)
        var table_body = document.createElement("tbody");
        $("#main").html("Refreshing...");

 
        if (formData && formData.entries().next().done === false) {
            $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                success: function(response){
                    var jsonData = JSON.parse(response);
                    jsonData.forEach(function(obj) {
                        // Access fields of each object
                        var table_row_body = document.createElement("tr");
                        var td_id = document.createElement("td");
                        
                        td_id.innerHTML = obj.pk;
                        
                        table_row_body.appendChild(td_id);
                        var td_user = document.createElement("td");
                        td_user.innerHTML = obj.fields.user_name;
                        td_user.classList.add("truncate");
                        table_row_body.appendChild(td_user)
                        var td_email = document.createElement("td");
                        td_email.innerHTML = obj.fields.email;
                        td_email.classList.add("truncate")
                        table_row_body.appendChild(td_email);

                        var td_message_body = document.createElement("td");
                        td_message_body.classList.add("truncate");
                        td_message_body.innerHTML = obj.fields.message_body;
                        table_row_body.appendChild(td_message_body);

                        var td_answered = document.createElement("td");
                        td_answered.innerHTML = obj.fields.is_responded ? "Answered" : "Pending";

                        table_row_body.style.cursor = "pointer";
                        table_row_body.addEventListener('click', function(){
                            showModal(obj);
                        })
                        table_row_body.appendChild(td_answered);
                        table_row_body.classList.add(obj.fields.is_urgent ? "table-danger" : "table-row");
                        table_body.appendChild(table_row_body);
                    }); 
                    table.appendChild(table_body)
                    table_container.appendChild(table);
                    $("#main").html(table_container);
                    $("#badge-message-count").html(jsonData.length)

                },
                error: function(error){
                    console.log(error)
                }
            })
        }else{
            console.log("FormData is empty");
        } 
    });
    $('#btn-get-messages').click();
})
